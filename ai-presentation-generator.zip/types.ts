
export interface Slide {
  title: string;
  content: string[];
  speakerNotes?: string;
}
